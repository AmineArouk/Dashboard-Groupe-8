# -*- coding: utf-8 -*-
import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule


class DoccumentSpider(CrawlSpider):
    name = 'doccument'
    allowed_domains = ['www.sciencedirect.com']
    user_agent = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/22.0.1207.1 Safari/537.1"
    #start_urls = ['https://www.sciencedirect.com/search/advanced?qs=Children%3B%20Adolescent%3B%20screen%3B%20media&offset=0']
    start_urls = ['https://www.sciencedirect.com/search/advanced?qs=Children%3B%20Adolescent%3B%20screen%3B%20media&offset=0']
    rules = (
        Rule(LinkExtractor(restrict_xpaths="//div[@class = 'result-item-content']/h2/span/a"), callback='parse_item', follow=True),
        Rule(LinkExtractor(restrict_xpaths = "//li[@class = 'pagination-link next-link']/a"))
     )

    def parse_item(self, response):
        nom_auteur1 = 0
        nom_auteur2 = 0
        nom_auteur3 = 0
        nom_auteur4 = 0
        nom_auteur5 = 0
        text = ""

        if (response.xpath("(//div[@class ='author-group']/a/span/span[@class ='text given-name'])[1]/text()")):
             namauthor_1 = response.xpath("(//div[@class ='author-group']/a/span/span[@class ='text given-name'])[1]/text()").get()
             sur_nam_1 = response.xpath("(//div[@class ='author-group']/a/span/span[@class ='text surname'])[1]/text()").get()
             nom_auteur1 = namauthor_1 + " " + sur_nam_1   

        if (response.xpath("(//div[@class ='author-group']/a/span/span[@class ='text given-name'])[2]/text()")):
             namauthor_2 = response.xpath("(//div[@class ='author-group']/a/span/span[@class ='text given-name'])[2]/text()").get()
             sur_nam_2 = response.xpath("(//div[@class ='author-group']/a/span/span[@class ='text surname'])[2]/text()").get()
             nom_auteur2 = namauthor_2 + " " + sur_nam_2   

        if (response.xpath("(//div[@class ='author-group']/a/span/span[@class ='text given-name'])[3]/text()")):
             namauthor_3 = response.xpath("(//div[@class ='author-group']/a/span/span[@class ='text given-name'])[3]/text()").get()
             sur_nam_3 = response.xpath("(//div[@class ='author-group']/a/span/span[@class ='text surname'])[3]/text()").get()
             nom_auteur3 = namauthor_3 + " " + sur_nam_3

        if (response.xpath("(//div[@class ='author-group']/a/span/span[@class ='text given-name'])[4]/text()")):
             namauthor_4 = response.xpath("(//div[@class ='author-group']/a/span/span[@class ='text given-name'])[4]/text()").get()
             sur_nam_4 = response.xpath("(//div[@class ='author-group']/a/span/span[@class ='text surname'])[4]/text()").get()
             nom_auteur4 = namauthor_4 + " " + sur_nam_4

        if (response.xpath("(//div[@class ='author-group']/a/span/span[@class ='text given-name'])[5]/text()")):
             namauthor_5 = response.xpath("(//div[@class ='author-group']/a/span/span[@class ='text given-name'])[5]/text()").get()
             sur_nam_5 = response.xpath("(//div[@class ='author-group']/a/span/span[@class ='text surname'])[5]/text()").get()
             nom_auteur5 = namauthor_5 + " " + sur_nam_5
       
        if  (nom_auteur5 !=0 ) :
             nom = nom_auteur1 + ", " + nom_auteur2 +  ", " + nom_auteur3 +  ", " + nom_auteur4 + ", " + nom_auteur5 
        elif (nom_auteur4 !=0): 
             nom = nom_auteur1 + ", " + nom_auteur2 + ", " + nom_auteur3 + nom_auteur4
        elif(nom_auteur3 !=0):
             nom = nom_auteur1 + ", " + nom_auteur2 + ", " + nom_auteur3
        elif(nom_auteur2 !=0):
             nom = nom_auteur1 + ", " + nom_auteur2
        else:
            nom = nom_auteur1
        
        
        contenu = response.xpath("(//div[@class ='Body u-font-serif']/div)[1]/descendant::node()/text()")
        if(contenu):
               text =  response.xpath("(//div[@class = 'Body u-font-serif']/div)[1]/descendant::node()/text()").getall()
          



        key_word4 = 0
        key_word2 = 0
        key_word1 = 0
        key_word3 = 0
        if (response.xpath("//div[@class = 'keywords-section']")):
            key_word1 = response.xpath("(//div[@class = 'keywords-section']/div[@class = 'keyword']/span/text())[1]").get()
            key_word2 = response.xpath("(//div[@class = 'keywords-section']/div[@class = 'keyword']/span/text())[2]").get()
            key_word3 = response.xpath("(//div[@class = 'keywords-section']/div[@class = 'keyword']/span/text())[3]").get()
            if (response.xpath("(//div[@class = 'keywords-section']/div[@class = 'keyword']/span/text())[4]")):
                key_word4 = response.xpath("(//div[@class = 'keywords-section']/div[@class = 'keyword']/span/text())[4]").get()
            if (key_word4 !=0 ):
                keywords = key_word1 + ", " + key_word2 + ", "+  key_word3 + ", " + key_word4
            elif(key_word3 !=0):
                keywords = key_word1 + ", " + key_word2 + ", "+  key_word3
            elif(key_word2 !=0):
                keywords = key_word1 + ", " + key_word2
        else:
            keywords = " "    
 

          




        




             

             

        yield {
                
                'Titre' : response.xpath("//h1[@id = 'screen-reader-main-title']/span[@class = 'title-text']/text()").get(),
                'abstract' : response.xpath(".//div[@class = 'abstract author']/div/p/text()").get(),
                'nom des auteurs' : nom,
                'Details ' : response.xpath(".//div[@class = 'text-xs']/text()").get(),
                'keywords' : keywords,
                'contenu' : text

                 }