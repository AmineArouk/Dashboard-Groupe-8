
drop table ecrire;
drop table parler;
drop table concerner;
drop table cause;
drop table sujet;
drop table effet;
drop table population;
drop table ecran;
drop table keywords;
drop table auteur;
drop table article;

------------------------------------------------------------
-- Table: Article
------------------------------------------------------------

CREATE TABLE Article(
        id_article       int NOT NULL ,
        titre            Varchar (200),
        date_publication Varchar (200)
	,CONSTRAINT Article_PK PRIMARY KEY (id_article)
);


------------------------------------------------------------
-- Table: Auteur
------------------------------------------------------------

CREATE TABLE Auteur(
        id_auteur     int NOT NULL ,
        nom_auteur    Varchar (50),
        prenom_auteur Varchar (50),
	CONSTRAINT Auteur_PK PRIMARY KEY (id_auteur)
);


------------------------------------------------------------
-- Table: Keywords
------------------------------------------------------------


CREATE TABLE Keywords(
        id_keywords int NOT NULL ,
        mot         Varchar (50)
	,CONSTRAINT Keywords_PK PRIMARY KEY (id_keywords)
);



------------------------------------------------------------
-- Table: Technologie
------------------------------------------------------------

CREATE TABLE Technologie(
        id_techno int NOT NULL ,
        nom_techno Varchar (50)
	,CONSTRAINT Techno_PK PRIMARY KEY (id_techno)
);

------------------------------------------------------------
-- Table: Population
------------------------------------------------------------

CREATE TABLE Population(
        id_pop     int NOT NULL ,
        classe_age Varchar (50) ,
        intervalle Varchar (50)
	,CONSTRAINT Population_PK PRIMARY KEY (id_pop)
);



------------------------------------------------------------
-- Table: Effet
------------------------------------------------------------

CREATE TABLE Effet(
        id_effet  int NOT NULL ,
        nom_effet Varchar (50) 
	,CONSTRAINT Effet_PK PRIMARY KEY (id_effet)
);



------------------------------------------------------------
-- Table: sujet
------------------------------------------------------------

CREATE TABLE sujet(
        id_article  int NOT NULL ,
        id_keywords int NOT NULL
	,CONSTRAINT sujet_PK PRIMARY KEY (id_article,id_keywords)

	,CONSTRAINT sujet_Article_FK FOREIGN KEY (id_article) REFERENCES Article(id_article)
	,CONSTRAINT sujet_Keywords0_FK FOREIGN KEY (id_keywords) REFERENCES Keywords(id_keywords)
);


------------------------------------------------------------
-- Table: causer
------------------------------------------------------------

CREATE TABLE causer(
        id_techno  int NOT NULL ,
        id_article int NOT NULL
	,CONSTRAINT causer_PK PRIMARY KEY (id_techno,id_article)

	,CONSTRAINT causer_Technologie_FK FOREIGN KEY (id_techno) REFERENCES Technologie(id_techno)
	,CONSTRAINT causer_Article0_FK FOREIGN KEY (id_article) REFERENCES Article(id_article)
);


------------------------------------------------------------
-- Table: concerner
------------------------------------------------------------

CREATE TABLE concerner(
        id_pop     int NOT NULL ,
        id_article int NOT NULL
	,CONSTRAINT concerner_PK PRIMARY KEY (id_pop,id_article)

	,CONSTRAINT concerner_Population_FK FOREIGN KEY (id_pop) REFERENCES Population(id_pop)
	,CONSTRAINT concerner_Article0_FK FOREIGN KEY (id_article) REFERENCES Article(id_article)
);



------------------------------------------------------------
-- Table: parler
------------------------------------------------------------

CREATE TABLE parler(
        id_effet   int NOT NULL ,
        id_article int NOT NULL
	,CONSTRAINT parler_PK PRIMARY KEY (id_effet,id_article)

	,CONSTRAINT parler_Effet_FK FOREIGN KEY (id_effet) REFERENCES Effet(id_effet)
	,CONSTRAINT parler_Article0_FK FOREIGN KEY (id_article) REFERENCES Article(id_article)
);

------------------------------------------------------------
-- Table: Ecrire
------------------------------------------------------------

CREATE TABLE Ecrire(
        id_article int NOT NULL ,
        id_auteur  int NOT NULL
	,CONSTRAINT Ecrire_PK PRIMARY KEY (id_article,id_auteur)

	,CONSTRAINT Ecrire_Article_FK FOREIGN KEY (id_article) REFERENCES Article(id_article)
	,CONSTRAINT Ecrire_Auteur0_FK FOREIGN KEY (id_auteur) REFERENCES Auteur(id_auteur)
);

--Donner les droits à la base à l'ensemble de l'équipe
GRANT SELECT, INSERT, UPDATE, DELETE ON Article TO MSN1181A;
GRANT SELECT, INSERT, UPDATE, DELETE ON Effet TO MSN1181A;
GRANT SELECT, INSERT, UPDATE, DELETE ON Auteur TO MSN1181A;
GRANT SELECT, INSERT, UPDATE, DELETE ON Causer TO MSN1181A;
GRANT SELECT, INSERT, UPDATE, DELETE ON Concerner TO MSN1181A;
GRANT SELECT, INSERT, UPDATE, DELETE ON Ecrire TO MSN1181A;
GRANT SELECT, INSERT, UPDATE, DELETE ON Population TO MSN1181A;
GRANT SELECT, INSERT, UPDATE, DELETE ON Keywords TO MSN1181A;
GRANT SELECT, INSERT, UPDATE, DELETE ON Sujet TO MSN1181A;
GRANT SELECT, INSERT, UPDATE, DELETE ON Parler TO MSN1181A;
GRANT SELECT, INSERT, UPDATE, DELETE ON Technologie TO MSN1181A;

GRANT SELECT, INSERT, UPDATE, DELETE ON Article TO TLF2051A;
GRANT SELECT, INSERT, UPDATE, DELETE ON Effet TO TLF2051A;
GRANT SELECT, INSERT, UPDATE, DELETE ON Auteur TO TLF2051A;
GRANT SELECT, INSERT, UPDATE, DELETE ON Causer TO TLF2051A;
GRANT SELECT, INSERT, UPDATE, DELETE ON Concerner TO TLF2051A;
GRANT SELECT, INSERT, UPDATE, DELETE ON Ecrire TO TLF2051A;
GRANT SELECT, INSERT, UPDATE, DELETE ON Population TO TLF2051A;
GRANT SELECT, INSERT, UPDATE, DELETE ON Keywords TO TLF2051A;
GRANT SELECT, INSERT, UPDATE, DELETE ON Sujet TO TLF2051A;
GRANT SELECT, INSERT, UPDATE, DELETE ON Parler TO TLF2051A;
GRANT SELECT, INSERT, UPDATE, DELETE ON Technologie TO TLF2051A;
