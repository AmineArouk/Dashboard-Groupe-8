A lire pour bien comprendre le fonctionnement !

• PREMIERE ETAPE : SCRAPPER LES DONNEES

1/ aller dans le dossier CodeScrapping > dashbord > dashbord > spiders
2/ aller sur Anaconda > Environnement > Base root > Open terminal
3/ dans le terminal, se déplacer pour être dans le dossier spiders (regarder le chemin de l'étape 1)
4/ executer la commande suivante : scrapy crawl doccument.py -o scrapping.json
5/ un fichier apparaît dans le dossier spiders, il est nommé scrapping et contient le scrapping du site !

• DEUXIEME ETAPE : CREER LA BDD

1/ aller sur Oracle SQL Developer
2/ executer le fichier scriptSQL

• TROISIEME ETAPE : TRAITER LES DONNEES ET PEUPLER LA BDD

1/ changer les identifiants d'accès à la bdd 
2/ executer le fichier CodeGroupe10.ipynb