S'assurer d'avoir la librairie Oracle Client avec le dernière version (304 bits)

Pour lancer le dashboard :
-    Ouvrir le fichier « Dashboard_G8.yipnb »
-    Installer les packages
-    Relancer toutes les cellules
-    Cliquer sur le lien en fin de page
